# 昼夜簿 · 设计交付包

建议查看顺序：

1. 浏览器打开 **DayNight-interaction-review.html**：8张交互图、逐页改动说明、关键流程图。图像已内嵌，单文件可查看。
2. 浏览器打开 **DayNight-prototype.html**：体验页面切换、增改完成、回收站、AI预览与笔记关联。数据仅保存在当前浏览器。
3. 将 **DayNight-development-spec.md** 发给开发：按编号核对改动、字段、状态、统计、异常、迁移与验收。
4. **screens/** 可直接贴入需求文档；**DayNight-interaction-flow.svg** 可放大查看或导入设计工具。

注意：AI为演示，日期固定2026-10-27；这不是已接入现有系统的生产代码。完整规则和原型简化差异见开发说明第12.1节。
